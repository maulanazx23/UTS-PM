package com.example.recyclerapplication

object FoodsData {
    private val foodNames = arrayOf("Starboy - The Weekend",
        "BAIXO - ALT VER",
        "Jurus Rahasia Teleport - JKT48",
        "Love Lee - AKMU",
        "Popular - The Weekend",
        "Rapsodi - JKT48",
        "Take On Me - AHA",
        "Blinding Lights - The Weekend",
        "Rewrite The Stars - James Arthur",
        "Cupid - Twin Ver.",
        "Calm Down (with Selena Gomez)",
        "Seventeen - JKT48",
        "Kill Bill - SZA",
        "CANT STOP THE LONELINESS - Anri",
        "You Spin Me Round - Dead Or Alive")

    private val foodDetails = arrayOf("Starboy - The  Weekend Lagu yang gelap dan penuh atmosfer dari The Weeknd ini menyelami kekosongan yang bisa muncul karena ketenaran dan kelebihan. Liriknya menggunakan gambaran yang jelas untuk melukiskan dunia yang dipenuhi dengan narkoba, pesta, dan hubungan yang cepat berlalu. Kalimat seperti \"Saya hidup dalam kegelapan, ya, saya seorang anak bintang\" dan \"Lampu yang menyilaukan tapi saya tidak bisa melihat\" menyoroti kekecewaan dan keterasingan yang dapat menyertai ketenaran.",
        "BAIXO - ALT VER Lagu ini dapat dinyanyikan dari sudut pandang seseorang yang lebih pendek dari pasangannya, mengekspresikan kekaguman mereka dan mengatasi rasa tidak aman dalam hubungan. Versi alternatifnya (ALT VER) dapat mengeksplorasi aspek yang berbeda dari dinamika ini, mungkin berfokus pada tantangan atau situasi lucu yang muncul dari perbedaan tinggi badan.",
        "Jurus Rahasia Teleport - JKT48 Lagu Indonesia dari JKT48 ini mungkin merupakan lagu yang lucu dan menarik tentang perasaan magis cinta muda yang dibawa ke dunia lain ketika Anda bersama orang yang Anda sukai. Konsep \"teleportasi\" berfungsi sebagai metafora untuk emosi yang intens dan kondisi pikiran yang berubah yang dialami selama tahap awal cinta. Lirik lagu ini mungkin menyebutkan hal-hal seperti kupu-kupu di perut, perasaan pusing dan pusing, atau dunia di sekitar mereka yang memudar saat bersama orang yang mereka cintai.",
        "Love Lee - AKMU Lagu yang manis dan polos dari duo kakak beradik asal Korea Selatan, AKMU, ini merupakan contoh klasik dari lagu cinta anak muda. Liriknya kemungkinan besar menggambarkan perasaan kekaguman dan kasih sayang para penyanyi terhadap seseorang yang mereka sukai. Mereka mungkin menyebutkan hal-hal seperti tatapan mata, lamunan tentang orang tersebut, dan keinginan untuk mengenal mereka lebih baik. Melodi lagu yang ringan dan vokal yang ceria mencerminkan kegembiraan cinta anak muda yang polos.",
        "Popular - The Weekend Lagu dari The Weeknd ini menawarkan pandangan sinis tentang ketenaran dan popularitas. Liriknya mungkin menggambarkan panjangnya usaha yang dilakukan orang untuk disukai dan diterima, bahkan jika itu berarti mengorbankan jati diri mereka yang sebenarnya. The Weeknd mungkin mengkritik kedangkalan dan sifat singkat dari popularitas media sosial.",
        "Rapsodi - JKT48 Tanpa mengetahui liriknya secara spesifik, sulit untuk menentukan makna yang tepat. Namun, mengingat \"Rapsodi\" diterjemahkan menjadi \"Rhapsody\" yang sering mengacu pada ledakan emosi yang kuat, ini bisa menjadi lagu yang lebih dewasa oleh JKT48 dibandingkan dengan gaya mereka yang biasanya. Lagu ini mungkin mengeksplorasi tema patah hati, kehilangan, atau emosi yang kuat",
        "Take On Me - AHA Lagu klasik synth-pop dari A-ha ini menceritakan tentang seorang pria yang tertarik pada seorang wanita yang dilihatnya dalam buku komik. Liriknya menggambarkan keinginannya untuk memasuki dunia buku komik dan bersamanya. Melodi lagu yang menarik dan video musiknya yang khas membuatnya menjadi hit besar di tahun 1980-an.",
        "Blinding Lights - The Weekend Lagu lain dari The Weeknd, \"Blinding Lights\" adalah lagu dance-pop dengan nada gelap. Liriknya menggambarkan malam yang penuh dengan pesta dan kemabukan, tetapi ada rasa kekosongan dan kerinduan di baliknya. Judul lagu \"Blinding Lights\" dapat menjadi metafora untuk gangguan yang digunakan orang untuk menghilangkan rasa sakit emosional.",
        "Rewrite The Stars - James Arthur Lagu dari film \"The Greatest Showman\" ini adalah balada yang kuat tentang menentang ekspektasi dan memperjuangkan impian Anda. Para penyanyi mengekspresikan tekad mereka untuk mengubah takdir mereka dan menulis ulang bintang-bintang, bahkan jika orang lain meragukan mereka.",
        "Cupid - Twin Ver. - Lagu ini kemungkinan besar mengeksplorasi tema cinta, ketertarikan, dan keinginan. \"Twin Ver.\" mungkin mengindikasikan duet atau versi yang dinyanyikan dari sudut pandang yang berbeda.",
        "Calm Down (with Selena Gomez) - Lagu dari penyanyi Amerika, Rema, yang menampilkan Selena Gomez ini mungkin merupakan lagu yang santai dan asyik tentang tetap santai dan terkumpul dalam suatu hubungan. Liriknya mungkin menyindir pasangan yang bereaksi berlebihan atau terlalu dramatis. Vokal Selena Gomez dapat menambahkan tandingan yang menenangkan pada syair-syair lucu Rema.",
        "Seventeen - JKT48 - Lagu \"Seventeen\" dari JKT48 kemungkinan besar menggambarkan kegembiraan, kepolosan, dan penemuan diri yang muncul sebagai seorang remaja. Liriknya mungkin menyebutkan pengalaman seperti cinta pertama, persahabatan, kehidupan sekolah, dan mencari tahu siapa diri Anda. Judul \"Seventeen\" juga dapat memiliki arti khusus dalam budaya Indonesia yang berkaitan dengan masa remaja.",
        "Kill Bill - SZA - Lagu R&B dari SZA ini kemungkinan besar bercerita tentang seorang wanita yang kuat, mandiri, dan tidak takut untuk mendapatkan apa yang diinginkannya. Referensi ke \"Kill Bill\" bisa jadi merupakan metafora untuk tekadnya yang kuat atau anggukan pada tema film aksi balas dendam dan pemberdayaan.",
        "CANT STOP THE LONELINESS - Anri - Lagu oleh penyanyi Jepang, Anri ini kemungkinan besar membahas tentang perasaan kesepian dan keterasingan. Judul \"CAN'T STOP THE LONELINESS\" secara langsung menyampaikan tema tersebut, dan liriknya mungkin mengeksplorasi penyebab dan pengalaman kesepian.",
        "You Spin Me Round - Dead Or Alive - Lagu dansa berenergi tinggi dari Dead Or Alive ini adalah lagu pesta klasik. Liriknya yang menarik dan irama yang menghentak mendorong pendengarnya untuk bangkit dan menari. Judul sugestif \"You Spin Me Round\" menambah suasana ceria dan riang pada lagu ini.")

    private val foodsImages = intArrayOf(
        R.drawable.starboy,
        R.drawable.baixo,
        R.drawable.jurus,
        R.drawable.love,
        R.drawable.popular,
        R.drawable.rapsodi,
        R.drawable.take,
        R.drawable.blinding,
        R.drawable.rewrite,
        R.drawable.cupid,
        R.drawable.calm,
        R.drawable.seventeen,
        R.drawable.kill,
        R.drawable.cant,
        R.drawable.you)

    val listData: ArrayList<Foods>
        get() {
            val list = arrayListOf<Foods>()
            for (position in foodNames.indices) {
                val foods = Foods()
                foods.name = foodNames[position]
                foods.detail = foodDetails[position]
                foods.photo = foodsImages[position]
                list.add(foods)
            }
            return list
        }
}
